## 常用的conda指令

##### autodl加速器（当需要下载github的东西时）

```
#终端加速
source /etc/network_turbo

#Notebook加速
import subprocess
import os

result = subprocess.run('bash -c "source /etc/network_turbo && env | grep proxy"', shell=True, capture_output=True, text=True)
output = result.stdout
for line in output.splitlines():
    if '=' in line:
        var, value = line.split('=', 1)
        os.environ[var] = value
```



##### autodl批量下载（生成文件夹于压缩包）

```
# autodl服务器终端输入以下命令 安装打包相关软件
apt-get update && apt-get install -y zip
 
# 将目标文件夹进行打包，这个将你的result文件夹打包成result.zip
zip -r result.zip result

# 如果有多个文件夹，可以合并打包，这里会将文件夹1,2,3全部打包在target文件中
zip -r target.zip 文件夹1 文件夹2 文件夹3...
```





##### 创建新的python环境

```
conda create -n env_name python=3.x
conda create -n sadtalker python=3.10
```

##### 查看已有的python环境

```
conda env list
# 或者
conda info --envs
```

##### 进入已有的python环境

```
conda activate env_name
```

##### 退出当前的python环境

```
conda deactivate
```

##### 删除虚拟环境

```
conda remove -n Digital --all
```



##### 常用的pip指令

.txt的内容安装所需的包

```
pip install -r requirements.txt 
```

根据requirement.安装包

```
pip install package_name
pip install ...... --timeout 6000
```

pip 换清华源后缀

```
-i https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple --trusted-host=https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple
```

更常用：

```
pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple --upgrade

pip install gfpgan==1.3.8 -i https://mirrors.aliyun.com/pypi/simple --upgrade
pip install -r requ2.txt -i https://mirrors.aliyun.com/pypi/simple --upgrade
```

查看已有的包

```
pip list
```

查看当前环境下的包

```
conda list
```

查看当前激活环境

```
conda info --envs
```

在当前环境下下载包

```
conda install 【包名/包名=版本号】
```

