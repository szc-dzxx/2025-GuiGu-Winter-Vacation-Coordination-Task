# Markdown格式下的数学公式

#### 一、画图

1. 先声明

先打三个```后，打mermaid

2. 换行，输入`图表类型`以及`排列方式`

| 图表类型 |     需要输入      |
| :------: | :---------------: |
|  流程图  | flowchart / graph |
|          |                   |

|       排列方式        | 需要输入 |
| :-------------------: | :------: |
| 自上(top)而下(bottom) |    TB    |
|       自下而上        |    BT    |
|       从左往右        |    LR    |
|       从右到左        |    RL    |

  ```mermaid
    flowchart LR
    	k --> b --> c -->d 
      A["JS"]
      B["Mermaid"]
      C["Markdown 原生"]
      D["Markdown 定制"]
      A --制作了--> B --内嵌到了 --> C --衍生了--> D
  ```

  ```mermaid
      flowchart TB
      
        subgraph 从左到右
          direction LR
          声明图像类型1 --> 声明排列方向1 --> 声明图像内容1
        end
        
        
        subgraph 从右到左
          direction RL
          声明图像类型2 --> 声明排列方向2 --> 声明图像内容2
        end
        
        
        subgraph 上下分明
        
          direction LR
          
          subgraph 从上到下
            direction TB
            声明图像类型3 --> 声明排列方向3 --> 声明图像内容3
          end
          
          subgraph 从下到上
            direction BT
            声明图像类型4 --> 声明排列方向4 --> 声明图像内容4
          end
          
          从上到下 --> 从下到上
          
        end
        从左到右 --> 从右到左 --> 上下分明
  ```

[更多教程请看]([循序渐进-讲解Markdown进阶（Mermaid绘图）-附使用案例_mermaid markdown-CSDN博客](https://blog.csdn.net/qq_57508808/article/details/136110461))

#### 二、数学公式

1. 先打两个$$（在英文输入法下按Shift和4）

2. 再按回车

3. 常见演示：

上标：
$$
x^2
$$
下标：
$$
y_1
$$
分式:
$$
\frac{1}{2}
$$
根号:
$$
\sqrt{2}
$$
矢量:
$$
\vec{a}
$$
积分:
$$
\int{x}dx

\int_{1}^{2}{x}dx
$$
极限:
$$
\lim{a+b}
$$

$$
\lim_{n\rightarrow\infty}
\lim_{n\rightarrow+\infty}
$$

累加:
$$
\sum{a}
$$

$$
\sum_{n=1}^{100}{a_n}
$$

累乘:
$$
\prod{x}
$$

$$
\prod_{n=1}^{99}{x_n}
$$

函数/运算符:
$$
\sin
$$

$$
\log_58
$$

$$
\ln2
$$

$$
\lg10
$$

$$
\pm
$$

$$
\times
$$

$$
\cdot
$$

$$
\div
$$

$$
\neq
$$

$$
\equiv
$$

$$
\leq
$$

$$
\geq
$$



![img](https://i-blog.csdnimg.cn/blog_migrate/be41ccfc7f6da7a6bf3ea2402b72087d.png)

符号:
$$
\forall \\
\exists
$$

$$
\infty
$$

$$
\emptyset
$$

$$
\nabla
$$

$$
\angle
$$

$$
\because
$$

$$
\therefore
$$

$$
\bot
$$



希腊字母:
$$
\Gamma
$$

$$
\delta
$$

$$
\Delta
$$

$$
\zeta
$$

$$
\eta
$$

$$
\Theta
$$

$$
\theta
$$

$$
\pi
$$

$$
\Pi
$$

$$
\Phi
$$

$$
\Psi
$$

$$
\psi
$$

$$
\Omega
$$

$$
\omega
$$

$$
X
$$

$$
\chi
$$

$$
\varphi
$$

$$
\sigma
$$

$$
\rho
$$

$$
\xi
$$

$$
\mu
$$

$$
\lambda
$$

$$
\alpha
$$

$$
\beta
$$

$$
\gamma
$$

$$
\varepsilon
$$

![img](https://i-blog.csdnimg.cn/blog_migrate/c9d0c6bef37185f69397a3811c3e56f1.png)

花括号与换行
$$
c(u)=\begin{cases} \sqrt\frac{1}{N},u=0 \\ 
	 			   \sqrt\frac{2}{N},u\neq0
	 			   \end{cases}
$$


空格
$$
a \quad b
$$
矩阵
$$
a = \left[
\matrix{
  \alpha_1 & test1\\
  \alpha_2 & test2\\
  \alpha_3 & test3 
}
\right]
$$
行列式
$$
\left|\begin{matrix}
    a & b & c \\
    d & e & f \\
    g & h & i
   \end{matrix} \right|
$$
可变大小
$$
\cap
\\
\bigcap
\\
\bigcup \\
\int \\
\oint \\
\iint
$$


![img](https://i-blog.csdnimg.cn/blog_migrate/3584ca9757b18ccda9fc2df09049b410.png)

![img](https://i-blog.csdnimg.cn/blog_migrate/63f120e5a92375eabbeb19290819eb53.png)

![img](https://i-blog.csdnimg.cn/blog_migrate/ed74f0d61156d8ad809fd6588385895e.png)